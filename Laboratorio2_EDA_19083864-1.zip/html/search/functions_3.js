var searchData=
[
  ['escribirlaberinto',['escribirLaberinto',['../_laberinto_lab2_8c.html#a3bfce3a8c5a330dbe8da067e6dd4569d',1,'LaberintoLab2.c']]],
  ['escribirpasos',['escribirPasos',['../_laberinto_lab2_8c.html#a57553dbb0dad389043a8cee687f29e56',1,'LaberintoLab2.c']]]
];
