var searchData=
[
  ['buscarposiciones',['buscarPosiciones',['../_laberinto_lab2_8c.html#a17cb53b9998c355cde7838c47578c207',1,'LaberintoLab2.c']]],
  ['buscarpuerta',['buscarPuerta',['../_laberinto_lab2_8c.html#a99790f0357a80937eec0822ab006338d',1,'LaberintoLab2.c']]]
];
