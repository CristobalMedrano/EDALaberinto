var menudata={children:[
{text:"Página principal",url:"index.html"},
{text:"Páginas relacionadas",url:"pages.html"},
{text:"Estructuras de Datos",url:"annotated.html",children:[
{text:"Estructura de datos",url:"annotated.html"},
{text:"Índice de estructura de datos",url:"classes.html"}]},
{text:"Archivos",url:"files.html",children:[
{text:"Lista de archivos",url:"files.html"},
{text:"Globales",url:"globals.html",children:[
{text:"Todo",url:"globals.html"},
{text:"Funciones",url:"globals_func.html"}]}]}]}
